#!/bin/bash



# move to the upload target directory
BASEDIR=$(dirname $(readlink -f $0))
cd $BASEDIR


if [ ! -f /usr/local/nagios/etc/objects/CustomSQL.xml ] ; then
	mkdir /usr/local/nagios/etc/objects && cp $BASEDIR/CustomSQL.xml /usr/local/nagios/etc/objects
fi

if [ ! -f /usr/local/nagios/var/profile.csv ] ; then
	cp $BASEDIR/profile.csv  /usr/local/nagios/var
fi


