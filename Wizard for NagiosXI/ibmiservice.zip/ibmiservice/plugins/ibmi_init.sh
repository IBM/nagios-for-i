#!/bin/bash
java -cp /usr/local/nagios/libexec/nagios4i.jar com.ibm.nagios.config.Initialization
